from django.apps import AppConfig


class StudentinformationConfig(AppConfig):
    name = 'studentinformation'
