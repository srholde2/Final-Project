from django.contrib import admin
from studentinformation.models import Studentdetails, Coursedetails


# Register your models here.

admin.site.register(Studentdetails)
admin.site.register(Coursedetails)
