from django.shortcuts import render
from django.http import HttpResponse
from studentinformation.models import Studentdetails, Coursedetails
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required



# Create your views here.

@login_required
def home(request):
	context = {'name': 'Stuart'}
	return render(request, 'studentinformation/home.html', context)

def about(request):
	return HttpResponse('<h2>About Us Page</h2>')

@login_required
def studentinformationinfo(request):
	studentinformationdata = Studentdetails.objects.all()
	paginator = Paginator(studentinformationdata, 10)
	page = request.GET.get('page')
	studentinformationminiset = paginator.get_page(page)
	return render(request, 'studentinformation/studentdetails.html', {'data':studentinformationminiset})

@login_required
def courseinformationinfo(request):
	courseinformationdata = Coursedetails.objects.all()
	paginator = Paginator(courseinformationdata, 10)
	page = request.GET.get('page')
	courseinformationminiset = paginator.get_page(page)
	return render(request, 'studentinformation/coursedetails.html', {'data':courseinformationminiset})

@login_required
def studentenrollment(request):
	return render(request, 'studentinformation/studentenrollment.html')

def savedata(request):
	if('sid' and 'fname' and 'lname' and 'major' and 'year' and 'gpa' in request.GET):
		sid = int(request.GET.get('sid'))
		fname = request.GET.get('fname')
		lname = request.GET.get('lname')
		major = request.GET.get('major')
		year = request.GET.get('year')
		gpa = int(request.GET.get('gpa'))
		adddata = Studentdetails(studentid=sid, firstname=fname, lastname=lname, major=major, year=year, gpa=gpa)
		adddata.save()
		return HttpResponse("Success")
	


